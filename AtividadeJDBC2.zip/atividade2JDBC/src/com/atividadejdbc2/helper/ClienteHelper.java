package com.atividadejdbc2.helper;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.atividadejdbc2.entity.Cliente;
import com.atividadejdbc2.entity.Pedido;

public class ClienteHelper {

private EntityManager em;
	
	public ClienteHelper(EntityManager entityManager){
		this.em = entityManager;
	}
	
	public void createCliente(Cliente cliente) throws Exception{
		try{
			em.getTransaction().begin();
			em.persist(cliente);
			em.getTransaction().commit();
		} catch (Exception exception) {
			em.getTransaction().rollback(); 
			throw exception;
		} 
	}	
	
	public void createPedido(Pedido pedido) throws Exception{
		try{
			em.getTransaction().begin();
			em.persist(pedido);
			em.getTransaction().commit();
		} catch (Exception exception) {
			em.getTransaction().rollback(); 
			throw exception;
		} 
	}
	
	public List<Cliente> buscarClientes(){
		String qs =  "select *"
				               + "  from clientes";
		
		TypedQuery<Cliente> query = em.createQuery(qs, Cliente.class);
		
		List<Cliente> clientes = query.getResultList();
		
		return clientes;
	}
	
	public Cliente getCliente(int idCliente){
		String qs =  "select from clientes where id_cliente = " + idCliente;
		
		TypedQuery<Cliente> query = em.createQuery(qs, Cliente.class);
		
		Cliente cliente = (Cliente) query.getResultList();
		
		return cliente;
	}
}
