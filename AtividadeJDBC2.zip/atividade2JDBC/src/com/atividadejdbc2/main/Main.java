package com.atividadejdbc2.main;

import java.sql.Date; 

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.atividadejdbc2.entity.Cliente;
import com.atividadejdbc2.entity.Pedido;
import com.atividadejdbc2.helper.ClienteHelper;

public class Main {
	private static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("SCJ Persist�ncia Roteiro 5 JPA");
	private static EntityManager entityManager = entityManagerFactory.createEntityManager();
	
	private static ClienteHelper helper = new ClienteHelper(entityManager);

	public static void main(String[] args) {
		pedidoCleinte();
	}
	
	public static void pedidoCleinte(){
		try{
			Cliente cliente = new Cliente();
			cliente.setNome("Steve Jobs");
			cliente.setEmail("jobs.steve@heaven.com");
		
			Pedido pedido = new Pedido();
			pedido.setData(new Date(0));
			pedido.setDescricao("Bola de Basquete");
			pedido.setValor(1499);
			
			cliente.getPedidos().add(pedido);

			helper.createCliente(cliente);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}