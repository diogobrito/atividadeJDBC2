package com.atividadejdbc4.dao;

import java.util.List;

public interface Dao<T> {
	void add(T entity);
	List<T> list();
	void update(String statement);
	void remove(T entity);
	T getOne(int id);
}
