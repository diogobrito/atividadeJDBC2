package com.atividadejdbc4.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {
	private static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("atividade4-29scj");
	
	public static EntityManager getEntityManager(){
		return entityManagerFactory.createEntityManager();
	}
}
