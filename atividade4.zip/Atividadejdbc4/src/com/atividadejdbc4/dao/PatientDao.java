package com.atividadejdbc4.dao;

import com.atividadejdbc4.entity.Paciente;

public class PatientDao extends GenericDao<Paciente>{
	public PatientDao() {
		super(Paciente.class);
	};
	
	public void update(Paciente patient) {
		statement =  "update paciente p"
		           + "   set p.nome = " + patient.getName()
		           + "     , p.dt_nascimento = " + patient.getBirthDate()
		           + "     , p.telefone = " + patient.getPhoneNumber()
		           + " where p.cpf_cliente = " + patient.getPatientCPF();

		super.update(statement);
	}
}