package com.atividadejdbc4.dao;

import com.atividadejdbc4.entity.Agenda;

public class ScheduleDao extends GenericDao<Agenda>{
	public ScheduleDao() {
		super(Agenda.class);
	}
	
	public void update(Agenda schedule) {
		statement =  "update agenda a"
		           + "   set a.data = " + schedule.getScheduleDate()
		           + "     , a.hora = " + schedule.getScheduleTime()
		           + "     , a.descricao = " + schedule.getDescription()
		           + " where a.id_agenda = " + schedule.getScheduleId();

		super.update(statement);
	}
}
