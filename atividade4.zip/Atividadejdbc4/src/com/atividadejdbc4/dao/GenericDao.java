package com.atividadejdbc4.dao;

import java.util.List;

import javax.persistence.EntityManager;

public class GenericDao<T> implements Dao<T>{
	private final Class<T> genericObject;
	protected EntityManager entityManager;
	protected String statement;
	
	public GenericDao(Class<T> genericObject){
		this.genericObject = genericObject;
	}

	@Override
	public void add(T entity) {
		entityManager = JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(entity);
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> list() {
		entityManager = JPAUtil.getEntityManager();
		
		String query = "select c from " + genericObject.getSimpleName() + " as c";
		List<T> returnList = entityManager.createQuery(query).getResultList();
		
		entityManager.close();
		
		return returnList;
	}

	@Override
	public void update(String statement) {
		entityManager = JPAUtil.getEntityManager();
		
		entityManager.createQuery(statement).executeUpdate();

		entityManager.close();
	}

	@Override
	public void remove(T entity) {
		entityManager = JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
		entityManager.remove(entityManager.merge(entity));
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@Override
	public T getOne(int id) {
		entityManager = JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
		T entity = entityManager.find(genericObject, id);
		entityManager.close();
		
		return entity;
	}
}
