package com.atividadejdbc4.main;

import java.util.Date;

import com.atividadejdbc4.dao.ScheduleDao;
import com.atividadejdbc4.entity.Paciente;
import com.atividadejdbc4.entity.Agenda;

public class Main {

	public static void main(String[] args) {
		Agenda schedule = new Agenda();
		
		schedule.setScheduleDate(new Date());
		schedule.setScheduleTime(new Date());
		schedule.setDescription("Teste Agenda3");
		
		
		
/*		Patient patient = new Patient();
		
		patient.setPatientCPF("12345678987");
		patient.setBirthDate(new Date());
		patient.setPhoneNumber("11999998888");
		patient.getSchedules().add(schedule); */
		
		
		ScheduleDao scheduleDao = new ScheduleDao();
		scheduleDao.add(schedule);
		
		System.out.println("Retorna Lista");
		for (Agenda dbSchedule : scheduleDao.list()) {
			System.out.println(dbSchedule.getDescription());
		}
		
		System.out.println("\n\n\nRetorna 1");
		System.out.println(scheduleDao.getOne(1).getDescription());
	}

}
