package com.atividadejdbc4.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="agenda_paciente", schema="consultorio")
public class AgendaPaciente implements Serializable{

	private static final long serialVersionUID = 279232006441731503L;
	
	
	@Id
	@Column(name="id_agenda_paciente")
	private int idAgendaPaciente;
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="agenda")
	@JoinTable(name="agenda", joinColumns=@JoinColumn(name="cpf_paciente"), inverseJoinColumns=@JoinColumn(name="id_agenda"))
	private List<Agenda> agenda;

	public int getIdAgendaPaciente() {
		return idAgendaPaciente;
	}

	public void setIdAgendaPaciente(int idAgendaPaciente) {
		this.idAgendaPaciente = idAgendaPaciente;
	}

	public List<Agenda> getAgenda() {
		return agenda;
	}

	public void setAgenda(List<Agenda> agenda) {
		this.agenda = agenda;
	}

}
