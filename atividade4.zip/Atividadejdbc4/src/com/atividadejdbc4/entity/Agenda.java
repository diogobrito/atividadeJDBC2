package com.atividadejdbc4.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="agenda", schema="consultorio")
public class Agenda implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_agenda")
	private int agendaId;
	
	@Temporal(TemporalType.DATE)
	@Column(name="data")
	private Date dataAgenda;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="hora")
	private Date horaAgenda;
	
	@Column(name="descricao")
	private String descricao;

	@ManyToMany(mappedBy="agenda")
	private List<Paciente> pacientes;
	
	public int getScheduleId() {
		return agendaId;
	}

	public void setIdSchedule(int scheduleId) {
		this.agendaId = scheduleId;
	}

	public Date getScheduleDate() {
		return dataAgenda;
	}

	public void setScheduleDate(Date scheduleDate) {
		this.dataAgenda = scheduleDate;
	}

	public Date getScheduleTime() {
		return horaAgenda;
	}

	public void setScheduleTime(Date scheduleTime) {
		this.horaAgenda = scheduleTime;
	}

	public String getDescription() {
		return descricao;
	}

	public void setDescription(String description) {
		this.descricao = description;
	}
	
	public List<Paciente> getPatients() {
		return pacientes;
	}
	
	public void setPatients(List<Paciente> patients) {
		this.pacientes = patients;
	}
}
