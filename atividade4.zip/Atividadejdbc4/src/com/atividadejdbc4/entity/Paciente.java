package com.atividadejdbc4.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="paciente", schema="consultorio")
public class Paciente implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="cpf_paciente")
	private String cpfPaciente;
	
	@Column(name="nome")
	private String nome;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dt_nascimento")
	private Date dataNascimentoo;
	
	@Column(name="telefone")
	private String telefone;
	
	@ManyToMany
	@JoinTable(name="agenda_paciente", joinColumns=@JoinColumn(name="cpf_paciente"), inverseJoinColumns=@JoinColumn(name="id_agenda"))
	private List<Agenda> agenda;
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="paciente")
	private List<Procedimento> proceddimentos;
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="paciente")
	private List<Matmed> equipamentos;

	public String getCpfPaciente() {
		return cpfPaciente;
	}

	public void setCpfPaciente(String cpfPaciente) {
		this.cpfPaciente = cpfPaciente;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getDataNascimentoo() {
		return dataNascimentoo;
	}

	public void setDataNascimentoo(Date dataNascimentoo) {
		this.dataNascimentoo = dataNascimentoo;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public List<Agenda> getAgenda() {
		return agenda;
	}

	public void setAgenda(List<Agenda> agenda) {
		this.agenda = agenda;
	}

	public List<Procedimento> getProceddimentos() {
		return proceddimentos;
	}

	public void setProceddimentos(List<Procedimento> proceddimentos) {
		this.proceddimentos = proceddimentos;
	}

	public List<Matmed> getEquipamentos() {
		return equipamentos;
	}

	public void setEquipamentos(List<Matmed> equipamentos) {
		this.equipamentos = equipamentos;
	}

	
}
