package com.atividadejdbc4.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="procedimento", schema="consultorio")
public class Procedimento implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_procedimento")
	private int procedureId;
	
	@Column(name="descricao")
	private String description;
	
	@Column(name="valor")
	private double price;
	
	@ManyToOne
	@JoinColumn(name="cpf_paciente")
	private Paciente patient;
	
	public int getProcedureId() {
		return procedureId;
	}

	public void setProcedureId(int procedureId) {
		this.procedureId = procedureId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Paciente getPacient() {
		return patient;
	}

	public void setPacient(Paciente pacient) {
		this.patient = pacient;
	}
}
